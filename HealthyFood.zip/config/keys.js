const secretOrKey = 'secret';

module.exports = {
  secretOrKey
};