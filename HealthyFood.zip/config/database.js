const mysql = require('mysql2');

const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    database: 'reactiv2_healthy_food',
    password: ''
});

if (process.env.NODE_ENV === 'production') {
    pool = mysql.createPool({
        host: '103.129.220.6',
        user: 'reactiv2_username',
        database: 'reactiv2_healthy_food',
        password: 'username_47'
    });
}

module.exports = pool.promise();
